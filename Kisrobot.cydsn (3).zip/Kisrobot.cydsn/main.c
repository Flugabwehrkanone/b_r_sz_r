/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"


    typedef enum 
    {
        Idle_state, 
        Seek_line, 
        Line_left, 
        Line_right,
        No_line, 
        On_line,
        
    } states;
    /*állapotok_______________________________________________________________*/

    typedef enum 
    {
        Dont_seek_line,
        IRL_detect,
        IRR_detect,
        No_line_seen, 
        On_line_seen,
        Direction_set,

    } events;
    /*eventek_________________________________________________________________*/

    events Readevent(int16 sensorLeft,int16 sensorRight){
        
        /*if(Start_Read() == 1){
        
            return Dont_seek_line;
        }*/
        if(sensorLeft ==0 && sensorRight ==0){
        
            return No_line_seen;
        }
        if(sensorRight ==1 && sensorLeft ==1){
                    
            return On_line_seen;
        }
        if(sensorRight ==1 && sensorLeft ==0){
               
            return IRR_detect;
        }
        if(sensorLeft ==1 && sensorRight ==0){
            
            return IRL_detect;
        }
        return Dont_seek_line;
    }
    /* event handler__________________________________________________________*/

    void setspeed(int16 left, int16 right){
        int8_t killcontrol=0;
        if(left<0){
            PWM_L_WriteCompare(-1*left);
            Left_mot_dir_Write(1);
        }else{
            PWM_L_WriteCompare(left);
            Left_mot_dir_Write(0);
        }
       if(right<0){
            PWM_R_WriteCompare(-1*right);
            Right_mot_dir_Write(1);
        }else{
            PWM_R_WriteCompare(right);
            Right_mot_dir_Write(0);
        } 
        if(left==0){
            killcontrol=1;
        }
        
        if(right==0){
            killcontrol=killcontrol+2;
        }
        Reg_PWM_Start_Write(killcontrol);
    }
    /*sebesség beállítása_____________________________________________________*/
    
    uint32_t lasttime=0;
    uint8_t ismytimer(){
        uint32_t now = CySysTickGetValue();
        if(now-lasttime > 100){
            return 1;
        }
        return 0;
    }
    /*időzítő_________________________________________________________________*/

     uint8_t ismytimer2(){
        uint32_t now = CySysTickGetValue();
        if(now-lasttime > 5000){
            return 1;
        }
        return 0;
    }
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    ADC_SAR_1_Start();
    LCD_Char_1_Start();
    PWM_L_Start();
    PWM_R_Start();
    setspeed(0,0);
    CySysTickStart();
    /*int16 sensorLeft=IR_L_Read();
    int16 sensorRight=IR_R_Read(); */ 
    states Newstate = Idle_state;
    events Newevent;
    /*int pressed;*/
    int16 result=0;
    int16 fast=0;
    int16 slow=0;
    for(;;)
    {
        /* Place your application code here. */
        /* Fekete => 1 */
        /* Fehér => 0 */
        /* fekete->"fehér" = 0 */
        
    
        while(1){    
       
        if(ismytimer()){
             ADC_SAR_1_StartConvert();
        result=ADC_SAR_1_GetResult16();
        ADC_SAR_1_StopConvert();
         
        if(ismytimer2()){
         LCD_Char_1_ClearDisplay();
         LCD_Char_1_PrintString("ADC result: ");
         LCD_Char_1_PrintNumber(result);
        fast=result;
        slow=result/20;
        }
        Newevent = Readevent(IR_L_Read(),IR_R_Read()); 
        switch(Newstate){
            
            case Idle_state:
                if(Dont_seek_line == Newevent){
                    setspeed(0,0);
                }else{
                    Newstate = Seek_line;
                }
                break;
                
            case Seek_line:
             
                if(IRR_detect == Newevent){
                    Newstate = Line_left;
                    }
                else if(IRL_detect == Newevent){
                    Newstate = Line_right;
                    }
                else if(No_line_seen == Newevent){
                    Newstate = No_line;
                    }
                else if(On_line_seen == Newevent){
                    Newstate = On_line;
                }               
                break;   
                
            case Line_left:
                setspeed(fast, slow);
                Newstate = Seek_line;
                break;
                
            case Line_right:
                setspeed(slow, fast);
                Newstate = Seek_line;
                break;
                
            case No_line:
                setspeed(fast, fast);
                Newstate = Seek_line;
                break;
                
            case On_line:
                setspeed(fast,fast);
                Newstate = Seek_line;
                break;
             
            default:
                setspeed(0,0);        
                }    
            
        }
    } 
}
}
/* [] END OF FILE */

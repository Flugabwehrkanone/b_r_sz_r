/*******************************************************************************
* File Name: Fire.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Fire_H) /* Pins Fire_H */
#define CY_PINS_Fire_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Fire_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Fire__PORT == 15 && ((Fire__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Fire_Write(uint8 value);
void    Fire_SetDriveMode(uint8 mode);
uint8   Fire_ReadDataReg(void);
uint8   Fire_Read(void);
void    Fire_SetInterruptMode(uint16 position, uint16 mode);
uint8   Fire_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Fire_SetDriveMode() function.
     *  @{
     */
        #define Fire_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Fire_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Fire_DM_RES_UP          PIN_DM_RES_UP
        #define Fire_DM_RES_DWN         PIN_DM_RES_DWN
        #define Fire_DM_OD_LO           PIN_DM_OD_LO
        #define Fire_DM_OD_HI           PIN_DM_OD_HI
        #define Fire_DM_STRONG          PIN_DM_STRONG
        #define Fire_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Fire_MASK               Fire__MASK
#define Fire_SHIFT              Fire__SHIFT
#define Fire_WIDTH              1u

/* Interrupt constants */
#if defined(Fire__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Fire_SetInterruptMode() function.
     *  @{
     */
        #define Fire_INTR_NONE      (uint16)(0x0000u)
        #define Fire_INTR_RISING    (uint16)(0x0001u)
        #define Fire_INTR_FALLING   (uint16)(0x0002u)
        #define Fire_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Fire_INTR_MASK      (0x01u) 
#endif /* (Fire__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Fire_PS                     (* (reg8 *) Fire__PS)
/* Data Register */
#define Fire_DR                     (* (reg8 *) Fire__DR)
/* Port Number */
#define Fire_PRT_NUM                (* (reg8 *) Fire__PRT) 
/* Connect to Analog Globals */                                                  
#define Fire_AG                     (* (reg8 *) Fire__AG)                       
/* Analog MUX bux enable */
#define Fire_AMUX                   (* (reg8 *) Fire__AMUX) 
/* Bidirectional Enable */                                                        
#define Fire_BIE                    (* (reg8 *) Fire__BIE)
/* Bit-mask for Aliased Register Access */
#define Fire_BIT_MASK               (* (reg8 *) Fire__BIT_MASK)
/* Bypass Enable */
#define Fire_BYP                    (* (reg8 *) Fire__BYP)
/* Port wide control signals */                                                   
#define Fire_CTL                    (* (reg8 *) Fire__CTL)
/* Drive Modes */
#define Fire_DM0                    (* (reg8 *) Fire__DM0) 
#define Fire_DM1                    (* (reg8 *) Fire__DM1)
#define Fire_DM2                    (* (reg8 *) Fire__DM2) 
/* Input Buffer Disable Override */
#define Fire_INP_DIS                (* (reg8 *) Fire__INP_DIS)
/* LCD Common or Segment Drive */
#define Fire_LCD_COM_SEG            (* (reg8 *) Fire__LCD_COM_SEG)
/* Enable Segment LCD */
#define Fire_LCD_EN                 (* (reg8 *) Fire__LCD_EN)
/* Slew Rate Control */
#define Fire_SLW                    (* (reg8 *) Fire__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Fire_PRTDSI__CAPS_SEL       (* (reg8 *) Fire__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Fire_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Fire__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Fire_PRTDSI__OE_SEL0        (* (reg8 *) Fire__PRTDSI__OE_SEL0) 
#define Fire_PRTDSI__OE_SEL1        (* (reg8 *) Fire__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Fire_PRTDSI__OUT_SEL0       (* (reg8 *) Fire__PRTDSI__OUT_SEL0) 
#define Fire_PRTDSI__OUT_SEL1       (* (reg8 *) Fire__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Fire_PRTDSI__SYNC_OUT       (* (reg8 *) Fire__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Fire__SIO_CFG)
    #define Fire_SIO_HYST_EN        (* (reg8 *) Fire__SIO_HYST_EN)
    #define Fire_SIO_REG_HIFREQ     (* (reg8 *) Fire__SIO_REG_HIFREQ)
    #define Fire_SIO_CFG            (* (reg8 *) Fire__SIO_CFG)
    #define Fire_SIO_DIFF           (* (reg8 *) Fire__SIO_DIFF)
#endif /* (Fire__SIO_CFG) */

/* Interrupt Registers */
#if defined(Fire__INTSTAT)
    #define Fire_INTSTAT            (* (reg8 *) Fire__INTSTAT)
    #define Fire_SNAP               (* (reg8 *) Fire__SNAP)
    
	#define Fire_0_INTTYPE_REG 		(* (reg8 *) Fire__0__INTTYPE)
#endif /* (Fire__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Fire_H */


/* [] END OF FILE */

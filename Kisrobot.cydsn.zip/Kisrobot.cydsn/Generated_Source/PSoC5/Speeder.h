/*******************************************************************************
* File Name: Speeder.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Speeder_H) /* Pins Speeder_H */
#define CY_PINS_Speeder_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Speeder_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Speeder__PORT == 15 && ((Speeder__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Speeder_Write(uint8 value);
void    Speeder_SetDriveMode(uint8 mode);
uint8   Speeder_ReadDataReg(void);
uint8   Speeder_Read(void);
void    Speeder_SetInterruptMode(uint16 position, uint16 mode);
uint8   Speeder_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Speeder_SetDriveMode() function.
     *  @{
     */
        #define Speeder_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Speeder_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Speeder_DM_RES_UP          PIN_DM_RES_UP
        #define Speeder_DM_RES_DWN         PIN_DM_RES_DWN
        #define Speeder_DM_OD_LO           PIN_DM_OD_LO
        #define Speeder_DM_OD_HI           PIN_DM_OD_HI
        #define Speeder_DM_STRONG          PIN_DM_STRONG
        #define Speeder_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Speeder_MASK               Speeder__MASK
#define Speeder_SHIFT              Speeder__SHIFT
#define Speeder_WIDTH              1u

/* Interrupt constants */
#if defined(Speeder__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Speeder_SetInterruptMode() function.
     *  @{
     */
        #define Speeder_INTR_NONE      (uint16)(0x0000u)
        #define Speeder_INTR_RISING    (uint16)(0x0001u)
        #define Speeder_INTR_FALLING   (uint16)(0x0002u)
        #define Speeder_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Speeder_INTR_MASK      (0x01u) 
#endif /* (Speeder__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Speeder_PS                     (* (reg8 *) Speeder__PS)
/* Data Register */
#define Speeder_DR                     (* (reg8 *) Speeder__DR)
/* Port Number */
#define Speeder_PRT_NUM                (* (reg8 *) Speeder__PRT) 
/* Connect to Analog Globals */                                                  
#define Speeder_AG                     (* (reg8 *) Speeder__AG)                       
/* Analog MUX bux enable */
#define Speeder_AMUX                   (* (reg8 *) Speeder__AMUX) 
/* Bidirectional Enable */                                                        
#define Speeder_BIE                    (* (reg8 *) Speeder__BIE)
/* Bit-mask for Aliased Register Access */
#define Speeder_BIT_MASK               (* (reg8 *) Speeder__BIT_MASK)
/* Bypass Enable */
#define Speeder_BYP                    (* (reg8 *) Speeder__BYP)
/* Port wide control signals */                                                   
#define Speeder_CTL                    (* (reg8 *) Speeder__CTL)
/* Drive Modes */
#define Speeder_DM0                    (* (reg8 *) Speeder__DM0) 
#define Speeder_DM1                    (* (reg8 *) Speeder__DM1)
#define Speeder_DM2                    (* (reg8 *) Speeder__DM2) 
/* Input Buffer Disable Override */
#define Speeder_INP_DIS                (* (reg8 *) Speeder__INP_DIS)
/* LCD Common or Segment Drive */
#define Speeder_LCD_COM_SEG            (* (reg8 *) Speeder__LCD_COM_SEG)
/* Enable Segment LCD */
#define Speeder_LCD_EN                 (* (reg8 *) Speeder__LCD_EN)
/* Slew Rate Control */
#define Speeder_SLW                    (* (reg8 *) Speeder__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Speeder_PRTDSI__CAPS_SEL       (* (reg8 *) Speeder__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Speeder_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Speeder__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Speeder_PRTDSI__OE_SEL0        (* (reg8 *) Speeder__PRTDSI__OE_SEL0) 
#define Speeder_PRTDSI__OE_SEL1        (* (reg8 *) Speeder__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Speeder_PRTDSI__OUT_SEL0       (* (reg8 *) Speeder__PRTDSI__OUT_SEL0) 
#define Speeder_PRTDSI__OUT_SEL1       (* (reg8 *) Speeder__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Speeder_PRTDSI__SYNC_OUT       (* (reg8 *) Speeder__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Speeder__SIO_CFG)
    #define Speeder_SIO_HYST_EN        (* (reg8 *) Speeder__SIO_HYST_EN)
    #define Speeder_SIO_REG_HIFREQ     (* (reg8 *) Speeder__SIO_REG_HIFREQ)
    #define Speeder_SIO_CFG            (* (reg8 *) Speeder__SIO_CFG)
    #define Speeder_SIO_DIFF           (* (reg8 *) Speeder__SIO_DIFF)
#endif /* (Speeder__SIO_CFG) */

/* Interrupt Registers */
#if defined(Speeder__INTSTAT)
    #define Speeder_INTSTAT            (* (reg8 *) Speeder__INTSTAT)
    #define Speeder_SNAP               (* (reg8 *) Speeder__SNAP)
    
	#define Speeder_0_INTTYPE_REG 		(* (reg8 *) Speeder__0__INTTYPE)
#endif /* (Speeder__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Speeder_H */


/* [] END OF FILE */
